#!/bin/bash

hive -f /home/acadgild/project/scripts/create_hive_hbase_lookup.hql
